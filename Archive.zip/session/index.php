<?
	header ('Location: session.php?id=1');     exit();
?>