<?php
       $db = mysql_connect ("localhost","root", "root");
       mysql_select_db ("newlook", $db);
       mysql_set_charset("utf8");
?> 