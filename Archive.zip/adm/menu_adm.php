	<p class='reg_success'>Админка</p>
	<p class='reg_success' style='margin-top: -30px;'>
		<form class='error_reg' action='' method='GET'>
			<button type=submit formaction='adm_port.php' class='form_butt' value='Портфолио'>Портфолио</button>
			<button type=submit  formaction='adm_bd.php' class='form_butt' value='Фотосессии'>БД</button>
			<button type=submit  formaction='adm_location.php' class='form_butt' value='Локации'>Локации</button>
			<button type=submit  formaction='adm_projects.php' class='form_butt' value='Фотопроекты'>Фотопроекты</button>
			<button type=submit  formaction='adm_shedule.php' class='form_butt' value='Расписание'>Расписание</button>
			<button type=submit  formaction='adm_office.php' class='form_butt' value='Личный кабинет'>Личный кабинет</button>
		</form></p>